<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('getClient', 'Client\ApiController@Client');
Route::get('getClient/{id}', 'Client\ApiController@ClientById');
Route::post('create', 'Client\ApiController@ClientSave');
Route::put('updateClient/{id}', 'Client\ApiController@ClientUpdate');
Route::delete('deleteClient/{id}', 'Client\ApiController@Clientdelete');
 Route::group([
    'prefix' => 'auth'
], function () {
    Route::post('login', 'AuthController@login');
    Route::post('signup', 'AuthController@signup');
  
    Route::group([
      'middleware' => 'auth:api'
    ], function() {
        Route::get('logout', 'AuthController@logout');
        Route::get('user', 'AuthController@user');
    });
});